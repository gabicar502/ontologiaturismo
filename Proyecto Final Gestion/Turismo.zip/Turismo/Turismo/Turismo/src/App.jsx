import Login from './Login/Login';

function App() {
  return (
    <div>
      <h1>Login Turismo</h1>
      <Login />
    </div>
  );
}

export default App;
